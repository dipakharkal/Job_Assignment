package com.user.service;

import com.user.entities.UserProfile;

public interface UserProfileService {

public String createUserProfile(UserProfile userProfile);

}
